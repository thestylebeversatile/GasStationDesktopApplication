package GasStationApp;

import java.util.Scanner;

public class GasStationApp {
	
	private int regular1;
	private int diesel1;
	private int premium1;
	private String GasStationName1;;
	private String LocationName1;
	
	private int regular2;
	private int diesel2;
	private int premium2;
	private String GasStationName2;
	private String LocationName2;
	
	private int regular3;
	private int diesel3;
	private int premium3;
	private String GasStationName3;
	private String LocationName3;
	
	private String FinalGasStationRegular;
	private String FinalGasStationDiesel;
	private String FinalGasStationPremium;
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		GasStationApp obj1 = new GasStationApp();
		obj1.TakeInput();
		obj1.Regularprice();
		obj1.DieselPrice();
		obj1.PremiumPrice();
		obj1.Displayoutput();

	}

	public void TakeInput () {
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Please enter input for gas station name.");
		GasStationName1 = keyboard.next();
		System.out.println("Please enter input for regular.");
		regular1 = keyboard.nextInt();
		System.out.println("Please enter input for diesel.");
		diesel1 = keyboard.nextInt();
		System.out.println("Please enter input for premium.");
		premium1 = keyboard.nextInt();
		

		System.out.println("Please enter input for gas station name.");
		GasStationName2 = keyboard.next();
		System.out.println("Please enter input for regular.");
		regular2 = keyboard.nextInt();
		System.out.println("Please enter input for diesel.");
		diesel2 = keyboard.nextInt();
		System.out.println("Please enter input for premium.");
		premium2 = keyboard.nextInt();
		
		System.out.println("Please enter input for gas station name.");
		GasStationName3 = keyboard.next();
		System.out.println("Please enter input for regular.");
		regular3 = keyboard.nextInt();
		System.out.println("Please enter input for diesel.");
		diesel3 = keyboard.nextInt();
		System.out.println("Please enter input for premium.");
		premium3 = keyboard.nextInt();
		
	}
	
	public void Regularprice () { 
		
		if (regular1 < regular2 && regular1 < regular3) { 
			FinalGasStationRegular = GasStationName1;
		}
		if (regular2 < regular1 && regular2 < regular3) { 
			FinalGasStationRegular = GasStationName2;
		}
		if (regular3 < regular1 && regular3 < regular2) { 
			FinalGasStationRegular = GasStationName3;
		}
		else { 
			FinalGasStationRegular = GasStationName1;
		} 
		
	}
	
	public void DieselPrice () {
		if (diesel1 < diesel2 && diesel1 < diesel3) { 
			FinalGasStationDiesel = GasStationName1;
		}
		if (diesel2 < diesel1 && diesel2 < diesel3) { 
			FinalGasStationDiesel = GasStationName2;
		}
		if (diesel3 < diesel1 && diesel3 < diesel2) { 
			FinalGasStationDiesel = GasStationName3;
		}
		else { 
			FinalGasStationDiesel = GasStationName1;
		} 
	}
	
	public void PremiumPrice () {
		if (premium1 < premium2 && premium1 < premium3) {
			FinalGasStationPremium = GasStationName1;
		}
		if (premium2 < premium1 && premium2 < premium3) { 
			FinalGasStationPremium = GasStationName2;
		}
		if (premium3 < premium1 && premium3 < premium2) { 
			FinalGasStationPremium = GasStationName3;
		}
		else { 
			FinalGasStationPremium = GasStationName1;
		}
	}	
	
	public void Displayoutput () { 
		System.out.println("Gas station name for minimum price of regular is :");
		System.out.println(FinalGasStationRegular);
		
		System.out.println("Gas station name for minimum price of diesel is :");
		System.out.println(FinalGasStationDiesel);
		
		System.out.println("Gas station name for minimum price of premium is : ");
		System.out.println(FinalGasStationPremium); 
	}
		
	}