package GasStationApp;

public class GasStationPrices {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
